#!/system/bin/sh
# Hamedis Performance Core (HPC) - manual control / Magisk action
#
# Usage:
#   sh /data/adb/modules/hamedis_performance_core/action.sh [command]
#
# Commands:
#   status        show current state (default)
#   cool          switch to COOL profile
#   balanced      switch to BALANCED profile
#   performance   switch to PERFORMANCE profile
#   gaming120     switch to GAMING120 profile (high-refresh gaming)
#   longevity     switch to LONGEVITY profile (damaged/hot hardware)
#   kernel        show kernel tunables and battery health
#   webui         start the web interface on port 1111
#   webstop       stop the web interface
#   probe         test which charge-control nodes this kernel allows
#   charge N      limit charging current to N mA (0 = remove limit)
#   limit N       stop charging at N percent (0 = disable)
#   game          force gaming profile now
#   stop-game     leave gaming profile, restore previous
#   reload        re-read config.conf and re-apply
#   reset         restore every original value and re-apply baseline
#   monitor [min] start recording a gaming session (default 20 min)
#   sessions      list saved sessions
#   save NAME     save the current session under a name
#   compare A B   compare two saved sessions side by side
#   report        summarise the recorded session
#   stopmon       stop recording early
#   log           show recent log lines
#   caps          show detected hardware capabilities
#   help          this text
# shellcheck disable=SC3043

MODDIR="${0%/*}"
# If invoked as a bare filename (no directory component), ${0%/*} yields
# the filename itself. Fall back to the current directory in that case.
[ "$MODDIR" = "$0" ] && MODDIR="."
case "$MODDIR" in
    /*) ;;                                   # already absolute
    *)  MODDIR="$(cd "$MODDIR" 2>/dev/null && pwd)" || MODDIR="${0%/*}" ;;
esac
export HPC_MODDIR="$MODDIR"

# shellcheck source=/dev/null
. "$MODDIR/scripts/common.sh"

hpc_bootstrap

CMD="${1:-status}"

# ----------------------------------------------------------------------
# helpers
# ----------------------------------------------------------------------

_module_active() {
    [ -f "$HPC_MODDIR/disable" ] && { printf 'DISABLED'; return; }
    if pgrep -f "$HPC_MODDIR/service.sh" >/dev/null 2>&1; then
        printf 'ACTIVE'
    elif [ -f "$HPC_STATE/current_profile" ]; then
        printf 'APPLIED (service not running)'
    else
        printf 'INACTIVE'
    fi
}

_pretty_game() {
    _pg=$(game_current_pkg)
    if [ -z "$_pg" ]; then
        printf 'none'
        return
    fi
    # Friendly names for the common ones; fall back to the package.
    case "$_pg" in
        com.mojang.minecraftpe)              printf 'Minecraft' ;;
        com.tencent.ig|com.pubg.krmobile|com.vng.pubgmobile|com.rekoo.pubgm)
                                             printf 'PUBG Mobile' ;;
        com.activision.callofduty.shooter|com.garena.game.codm)
                                             printf 'Call of Duty Mobile' ;;
        com.dts.freefireth|com.dts.freefiremax) printf 'Free Fire' ;;
        com.miHoYo.GenshinImpact|com.miHoYo.Yuanshen) printf 'Genshin Impact' ;;
        com.roblox.client)                   printf 'Roblox' ;;
        com.riotgames.league.wildrift)       printf 'Wild Rift' ;;
        *)                                   printf '%s' "$_pg" ;;
    esac
}

_switch() {
    _target="$1"
    _eff=$(battery_adjust_profile "$_target")
    apply_profile "$_eff"
    # Persist as the new baseline so it survives the next service tick.
    if [ -f "$HPC_CONFIG" ]; then
        _tmp="$HPC_CONFIG.tmp.$$"
        sed "s/^MODE=.*/MODE=$_target/" "$HPC_CONFIG" >"$_tmp" 2>/dev/null && \
            mv -f "$_tmp" "$HPC_CONFIG" 2>/dev/null || rm -f "$_tmp" 2>/dev/null
    fi
    if [ "$_eff" != "$_target" ]; then
        printf 'Profile: %s  (battery policy adjusted from %s)\n' \
            "$(printf '%s' "$_eff" | tr '[:lower:]' '[:upper:]')" \
            "$(printf '%s' "$_target" | tr '[:lower:]' '[:upper:]')"
    else
        printf 'Profile: %s\n' "$(printf '%s' "$_eff" | tr '[:lower:]' '[:upper:]')"
    fi
}

_status() {
    _prof=$(current_profile | tr '[:lower:]' '[:upper:]')
    _temp=$(thermal_read 2>/dev/null)
    _tstate=$(thermal_get_state)
    _tstep=$(thermal_get_step)
    _cap=$(battery_capacity 2>/dev/null)
    _btemp=$(battery_temp_c 2>/dev/null)
    _chg="no"; battery_charging 2>/dev/null && _chg="yes"
    _ram=$(ram_summary 2>/dev/null)
    _zram=$(zram_summary 2>/dev/null)

    printf '\n'
    printf '  %s\n' "$HPC_NAME"
    printf '  %s\n' '─────────────────────────────────────────'
    printf '  Profile      : %s\n' "$_prof"
    printf '  Game         : %s\n' "$(_pretty_game)"
    if [ -n "$_temp" ]; then
        printf '  CPU Temp     : %s°C\n' "$_temp"
    else
        printf '  CPU Temp     : unavailable\n'
    fi
    printf '  Thermal State: %s' "$_tstate"
    [ "$_tstep" != "0" ] && printf ' (step %s/3)' "$_tstep"
    printf '\n'
    printf '  Battery      : %s%%  %s°C  charging=%s\n' \
        "${_cap:-?}" "${_btemp:-?}" "$_chg"
    printf '  RAM          : %s\n' "${_ram:-unknown}"
    printf '  zRAM         : %s\n' "${_zram:-none}"
    printf '  Module       : %s\n' "$(_module_active)"
    printf '  %s\n' '─────────────────────────────────────────'
    printf '  CPU cores    : %s  (%s online)\n' "${CPU_COUNT:-?}" "$(cpu_online_state)"
    printf '  Clusters     : %s\n' "${CLUSTERS:-?}"
    printf '  Governor     : %s\n' "$(_current_gov)"
    printf '  GPU          : %s\n' "${GPU_VENDOR:-none}"
    command -v gfx_report >/dev/null 2>&1 && gfx_report
    printf '\n'
}

_current_gov() {
    for _p in $(detect_policies); do
        _g=$(read_node "$_p/scaling_governor" 2>/dev/null)
        [ -n "$_g" ] && { printf '%s' "$_g"; return 0; }
    done
    printf 'unknown'
}

# ----------------------------------------------------------------------
# dispatch
# ----------------------------------------------------------------------

case "$CMD" in
    status|"")
        _status
        ;;

    cool|balanced|performance|gaming90|gaming120|longevity)
        _switch "$CMD"
        ;;

    game)
        _hit=$(game_scan)
        if [ -n "$_hit" ]; then
            game_enter "${_hit%% *}" "${_hit#* }"
            printf 'Gaming profile active for: %s\n' "$(_pretty_game)"
        else
            # No game running: apply the gaming profile anyway, as asked.
            apply_profile "$(battery_adjust_profile "${GAME_PROFILE:-performance}")"
            printf 'No game detected. Gaming profile applied manually.\n'
        fi
        ;;

    stop-game)
        if [ -f "$HPC_STATE/game_pid" ]; then
            game_exit
            printf 'Gaming profile cleared. Restored: %s\n' \
                "$(current_profile | tr '[:lower:]' '[:upper:]')"
        else
            apply_profile "$(battery_adjust_profile "$MODE")"
            printf 'No game session. Baseline applied: %s\n' \
                "$(current_profile | tr '[:lower:]' '[:upper:]')"
        fi
        ;;

    reload)
        hpc_load_config
        run_detection
        load_capabilities
        apply_profile "$(battery_adjust_profile "$MODE")"
        printf 'Config reloaded. Profile: %s\n' \
            "$(current_profile | tr '[:lower:]' '[:upper:]')"
        ;;

    reset)
        printf 'Restoring all original values...\n'
        restore_all
        command -v gfx_restore_props >/dev/null 2>&1 && gfx_restore_props
        rm -f "$HPC_STATE/game_pid" "$HPC_STATE/game_pkg" \
              "$HPC_STATE/pre_game_profile" "$HPC_STATE/thermal_step" \
              "$HPC_STATE/thermal_state" 2>/dev/null
        : >"$HPC_BACKUP" 2>/dev/null
        run_detection
        load_capabilities
        apply_profile "$(battery_adjust_profile "$MODE")"
        printf 'Reset complete. Profile: %s\n' \
            "$(current_profile | tr '[:lower:]' '[:upper:]')"
        ;;

    monitor)
        _mins="${2:-20}"
        case "$_mins" in
            ''|*[!0-9]*) _mins=20 ;;
        esac
        [ "$_mins" -lt 1 ] && _mins=1
        [ "$_mins" -gt 120 ] && _mins=120

        if monitor_running; then
            printf 'A session is already recording. Stop it with: stopmon\n'
            exit 1
        fi

        # Archive the previous run first. Starting a new recording used
        # to silently destroy the old one, which made an A/B comparison
        # between two profiles impossible.
        _arch=$(monitor_archive "")
        [ -n "$_arch" ] && printf '  Previous session saved as: %s\n' \
            "$(basename "$_arch" .csv)"

        # Fresh file with a header row.
        printf 'time,soc_c,state,step,cpu_max_mhz,cpu_cur_mhz,gpu_pct,gpu_mhz,batt_pct,batt_c,profile,game\n' \
            >"$HPC_SESSION" 2>/dev/null

        monitor_loop "$_mins" "${MON_DEFAULT_INTERVAL:-5}" >/dev/null 2>&1 &
        _mpid=$!
        printf '%s' "$_mpid" >"$HPC_MON_PID" 2>/dev/null

        printf '\n'
        printf '  Recording for %s minutes.\n' "$_mins"
        printf '\n'
        printf '  Now: start your game and play normally.\n'
        printf '  Recording stops by itself - you can close this terminal.\n'
        printf '\n'
        printf '  When you are done:\n'
        printf '    sh %s report\n' "$0"
        printf '\n'
        log_info "monitor: started for ${_mins}m"
        ;;

    stopmon)
        if monitor_running; then
            monitor_stop
            printf 'Recording stopped.\n'
        else
            printf 'No recording in progress.\n'
        fi
        ;;

    report)
        printf '\n  %s - Session Report\n' "$HPC_NAME"
        printf '  ─────────────────────────────────────────\n'
        if monitor_running; then
            printf '  (recording still in progress)\n\n'
        fi
        monitor_report "${2:-}"
        ;;

    kernel)
        printf '\n  %s - Kernel\n' "$HPC_NAME"
        printf '  ─────────────────────────────────────────\n'
        km_report
        printf '\n'
        ;;

    webui)
        if web_start; then
            printf 'WebUI: http://127.0.0.1:%s\n' "${WEBUI_PORT:-1111}"
            web_open >/dev/null 2>&1
        else
            printf 'Failed to start WebUI.\n'
            exit 1
        fi
        ;;

    webstop)
        web_stop
        printf 'WebUI stopped.\n'
        ;;

    probe)
        km_probe_charge
        ;;

    charge)
        _ma="${2:-}"
        case "$_ma" in
            ''|*[!0-9]*) printf 'Usage: charge <mA>   e.g. charge 1000   (0 = remove)\n'; exit 1 ;;
        esac
        if [ "$_ma" -eq 0 ]; then
            sed -i 's/^CHARGE_CURRENT_MA=.*/CHARGE_CURRENT_MA=/' "$HPC_CONFIG" 2>/dev/null
            printf 'Charge current limit removed from config.\n'
            printf 'Reboot to fully restore the vendor default.\n'
        else
            _applied=$(km_set_charge_current "$_ma")
            if [ -n "$_applied" ]; then
                if grep -q '^CHARGE_CURRENT_MA=' "$HPC_CONFIG" 2>/dev/null; then
                    sed -i "s/^CHARGE_CURRENT_MA=.*/CHARGE_CURRENT_MA=$_applied/" "$HPC_CONFIG" 2>/dev/null
                else
                    printf 'CHARGE_CURRENT_MA=%s\n' "$_applied" >>"$HPC_CONFIG" 2>/dev/null
                fi
                printf 'Charge current limited to %s mA\n' "$_applied"
            else
                printf 'No writable charge-current node on this kernel.\n'
                printf 'Run:  sh %s probe    to see exactly why.\n' "$0"
                exit 1
            fi
        fi
        ;;

    limit)
        _lp="${2:-}"
        case "$_lp" in
            ''|*[!0-9]*) printf 'Usage: limit <percent>   e.g. limit 80   (0 = off)\n'
                         printf 'Minimum is 50%%: a lower ceiling keeps the phone near-empty.\n'
                         exit 1 ;;
        esac

        # BUG FIX (v1.8.1): persist the value the setter ACTUALLY applied.
        # Previously the raw request was written, so `limit 1` stored 1
        # and the soft engine paused charging at 1%.
        _applied=$(km_set_charge_limit "$_lp")
        case "$_applied" in
            ''|*[!0-9]*) printf 'Charge limit could not be applied.\n'; exit 1 ;;
        esac

        if [ "$_applied" -eq 0 ]; then
            km_release_charge_hold
            sed -i 's/^CHARGE_LIMIT_ENABLED=.*/CHARGE_LIMIT_ENABLED=0/' "$HPC_CONFIG" 2>/dev/null
            printf 'Charge limit disabled. Charging restored to 100%%.\n'
        else
            if ! km_has_native_limit && ! km_soft_limit_supported; then
                printf 'This kernel offers no charge control at all.\n'
                printf 'Run:  sh %s probe\n' "$0"
                exit 1
            fi
            if grep -q '^CHARGE_LIMIT_ENABLED=' "$HPC_CONFIG" 2>/dev/null; then
                sed -i "s/^CHARGE_LIMIT_ENABLED=.*/CHARGE_LIMIT_ENABLED=1/" "$HPC_CONFIG" 2>/dev/null
                sed -i "s/^CHARGE_LIMIT=.*/CHARGE_LIMIT=$_applied/" "$HPC_CONFIG" 2>/dev/null
            else
                printf 'CHARGE_LIMIT_ENABLED=1\nCHARGE_LIMIT=%s\n' "$_applied" >>"$HPC_CONFIG" 2>/dev/null
            fi
            printf 'Charging will stop at %s%%' "$_applied"
            [ "$_applied" != "$_lp" ] && printf '  (requested %s%%, clamped to the 50%% floor)' "$_lp"
            printf '\n'
        fi
        ;;

    log)
        _n="${2:-40}"
        if [ -f "$HPC_LOG_DIR/hpc.log" ]; then
            tail -n "$_n" "$HPC_LOG_DIR/hpc.log"
        else
            printf 'No log file yet.\n'
        fi
        ;;

    caps)
        if [ -f "$HPC_STATE/capabilities.conf" ]; then
            cat "$HPC_STATE/capabilities.conf"
        else
            run_detection && cat "$HPC_STATE/capabilities.conf"
        fi
        ;;

    help|-h|--help)
        sed -n '2,22p' "$0" | sed 's/^# \{0,1\}//'
        ;;

    *)
        printf 'Unknown command: %s\n' "$CMD"
        printf "Try: status | cool | balanced | performance | gaming90 | gaming120 | longevity | kernel | webui | probe | charge | limit | game | stop-game | monitor | report | sessions | save | compare | stopmon | reload | reset | log | caps\n"
        exit 1
        ;;
esac

exit 0
