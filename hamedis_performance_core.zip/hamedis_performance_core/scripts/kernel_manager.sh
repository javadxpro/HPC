#!/system/bin/sh
# Hamedis Performance Core (HPC) - kernel manager
#
# Exposes the kernel tunables that HPC did not already cover:
#   - I/O scheduler and block queue
#   - TCP congestion control
#   - zRAM parameters (read + safe writes only)
#   - charge current / charge limit  <-- the big one for hot batteries
#   - wakelock inspection
#   - battery health and wear reporting
#
# Everything routes through safe_write(), so every change is backed up,
# verified and reversible, and any node this kernel does not expose is
# skipped and logged rather than causing an error.
# shellcheck disable=SC3043

HPC_DATA="${HPC_DATA:-/data/adb/hamedis}"
HPC_STATE="$HPC_DATA/state"

# ======================================================================
# I/O scheduler
# ======================================================================
#
# On UFS/eMMC the scheduler choice matters less than people claim, but
# read_ahead_kb genuinely affects app launch and texture streaming.
# We never pick a scheduler that is not in the kernel's own list.

km_block_devices() {
    # Physical backing devices only.
    #
    # dm-* are device-mapper virtual layers (dm-verity, dm-crypt on an
    # encrypted /data). Their queue knobs are owned by the mapper and are
    # never writable, so touching them produced a wall of SELinux
    # warnings with no benefit. Same for loop and zram.
    for _kb in /sys/block/sd? /sys/block/mmcblk[0-9] /sys/block/nvme[0-9]n[0-9]; do
        [ -d "$_kb/queue" ] && printf '%s\n' "$_kb"
    done
}

km_io_available() {
    # Prefer a device whose node still lists MULTIPLE schedulers. Some
    # kernels (and some vendor patches) collapse the list to just the
    # active name after a write, which would make us think only one
    # scheduler exists and refuse every subsequent change.
    _kia_best=""
    for _kia_d in $(km_block_devices); do
        _kl=$(read_node "$_kia_d/queue/scheduler" 2>/dev/null)
        [ -n "$_kl" ] || continue
        _kl=$(printf '%s' "$_kl" | tr -d '[]')
        _kia_n=$(printf '%s' "$_kl" | wc -w | tr -d ' ')
        if [ "${_kia_n:-0}" -gt 1 ]; then
            printf '%s' "$_kl"
            return 0
        fi
        [ -z "$_kia_best" ] && _kia_best="$_kl"
    done
    [ -n "$_kia_best" ] && { printf '%s' "$_kia_best"; return 0; }
    return 1
}

km_io_current() {
    for _kc in $(km_block_devices); do
        _kl=$(read_node "$_kc/queue/scheduler" 2>/dev/null)
        _sel=$(printf '%s' "$_kl" | sed -n 's/.*\[\([^]]*\)\].*/\1/p')
        [ -n "$_sel" ] && { printf '%s' "$_sel"; return 0; }
    done
    printf 'unknown'
}

# km_set_io SCHEDULER - only applies if the kernel lists it
# Accepts either a single name or a space-separated preference list.
# Kernels differ wildly: older ones expose noop/deadline/cfq, newer ones
# mq-deadline/kyber/bfq/none. A single hardcoded name silently does
# nothing on half of them.
km_set_io() {
    _sio_pref="$1"
    _sio_avail=$(km_io_available) || {
        log_unsupported "block scheduler" "no queue exposed"
        return 1
    }
    _sio_want=""
    for _sio_p in $_sio_pref; do
        for _sio_a in $_sio_avail; do
            [ "$_sio_p" = "$_sio_a" ] && { _sio_want="$_sio_p"; break; }
        done
        [ -n "$_sio_want" ] && break
    done
    if [ -z "$_sio_want" ]; then
        log_warn "no io scheduler from '$_sio_pref' available (have: $_sio_avail)"
        return 1
    fi
    _sio_ok=0
    for _sio_d in $(km_block_devices); do
        safe_write "$_sio_d/queue/scheduler" "$_sio_want" && _sio_ok=1
    done
    [ "$_sio_ok" -eq 1 ] && return 0
    return 1
}

km_apply_block() {
    [ -n "${IO_SCHEDULER:-}" ] && km_set_io "$IO_SCHEDULER"

    for _kq in $(km_block_devices); do
        [ -n "${IO_READ_AHEAD_KB:-}" ] && \
            safe_write "$_kq/queue/read_ahead_kb" "$IO_READ_AHEAD_KB"
        [ -n "${IO_NR_REQUESTS:-}" ] && \
            safe_write "$_kq/queue/nr_requests" "$IO_NR_REQUESTS"
        # iostats costs a little CPU per request; off is fine on a phone.
        [ -n "${IO_STATS:-}" ] && \
            safe_write "$_kq/queue/iostats" "$IO_STATS"
        # add_random drains entropy for no benefit on flash.
        [ -n "${IO_ADD_RANDOM:-}" ] && \
            safe_write "$_kq/queue/add_random" "$IO_ADD_RANDOM"
    done
    return 0
}

# ======================================================================
# Network
# ======================================================================

km_tcp_available() {
    read_node /proc/sys/net/ipv4/tcp_available_congestion_control 2>/dev/null
}

km_tcp_current() {
    read_node /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null
}

km_apply_tcp() {
    [ -n "${TCP_CONGESTION:-}" ] || return 0
    _avail=$(km_tcp_available) || return 1
    for _t in $_avail; do
        if [ "$_t" = "$TCP_CONGESTION" ]; then
            safe_write /proc/sys/net/ipv4/tcp_congestion_control "$TCP_CONGESTION"
            return 0
        fi
    done
    log_warn "tcp congestion '$TCP_CONGESTION' not available (have: $_avail)"
    return 1
}

# ======================================================================
# zRAM
# ======================================================================
#
# We READ zRAM config and report it. We do not resize it at runtime:
# that requires swapoff, which can stall the entire device for seconds.

km_zram_info() {
    _kz="${ZRAM_PATH:-}"
    [ -n "$_kz" ] || _kz=$(detect_zram 2>/dev/null)
    [ -n "$_kz" ] || return 1

    _ds=$(read_node "$_kz/disksize" 2>/dev/null)
    _orig=$(read_node "$_kz/orig_data_size" 2>/dev/null)
    _compr=$(read_node "$_kz/compr_data_size" 2>/dev/null)
    _algo=$(read_node "$_kz/comp_algorithm" 2>/dev/null | sed -n 's/.*\[\([^]]*\)\].*/\1/p')
    [ -n "$_algo" ] || _algo=$(read_node "$_kz/comp_algorithm" 2>/dev/null | awk '{print $1}')

    printf 'size=%s algo=%s' "${_ds:-0}" "${_algo:-?}"
    if [ -n "$_orig" ] && [ -n "$_compr" ] && [ "$_compr" -gt 0 ] 2>/dev/null; then
        printf ' ratio=%s.%sx' $(( _orig / _compr )) $(( (_orig * 10 / _compr) % 10 ))
    fi
    return 0
}

# ======================================================================
# Battery: charge control
# ======================================================================
#
# THIS IS THE SECTION THAT MATTERS FOR A HOT OR SWOLLEN BATTERY.
#
# Charging current is the single largest controllable source of battery
# heat. A cell charged at 2.0 A generates roughly four times the I^2R
# heating of one charged at 1.0 A. Halving the current roughly quarters
# the heat, at the cost of a slower charge.
#
# Charge ceiling matters too: the 80-100% region is where lithium cells
# spend the most time at high voltage, which is the main driver of both
# swelling and capacity loss. Capping at 80% dramatically slows wear.
#
# Every node here is optional and vendor-specific. Missing nodes are
# skipped silently.

km_charge_nodes() {
    _kb=$(detect_battery_path 2>/dev/null) || return 1
    printf '%s' "$_kb"
}

# Current charging rate in mA (negative = discharging)
km_charge_rate_ma() {
    _kb=$(km_charge_nodes) || return 1
    _cn=$(read_node "$_kb/current_now" 2>/dev/null)
    case "$_cn" in ''|*[!0-9-]*) return 1 ;; esac
    # Usually microamps
    if [ "$_cn" -gt 100000 ] || [ "$_cn" -lt -100000 ]; then
        printf '%s' $(( _cn / 1000 ))
    else
        printf '%s' "$_cn"
    fi
}

# Battery wear: full charge capacity vs design capacity
km_battery_health() {
    _kb=$(km_charge_nodes) || return 1
    _full=$(read_node "$_kb/charge_full" 2>/dev/null)
    _design=$(read_node "$_kb/charge_full_design" 2>/dev/null)
    _health=$(read_node "$_kb/health" 2>/dev/null)
    _cycles=$(read_node "$_kb/cycle_count" 2>/dev/null)

    printf 'health=%s' "${_health:-unknown}"
    [ -n "$_cycles" ] && printf ' cycles=%s' "$_cycles"

    case "$_full$_design" in
        ''|*[!0-9]*) return 0 ;;
    esac
    [ "$_design" -gt 0 ] 2>/dev/null || return 0
    _pct=$(( _full * 100 / _design ))
    printf ' capacity=%s%%' "$_pct"
    return 0
}

# Every charge-current node seen across Qualcomm/Xiaomi kernels.
# microamp nodes first, then milliamp ones (handled separately below).
KM_CURRENT_NODES_UA="
/sys/class/power_supply/battery/constant_charge_current_max
/sys/class/power_supply/battery/current_max
/sys/class/power_supply/battery/input_current_limit
/sys/class/power_supply/battery/fast_charge_current
/sys/class/power_supply/battery/battery_charging_current
/sys/class/power_supply/main/constant_charge_current_max
/sys/class/power_supply/main/current_max
/sys/class/power_supply/main/input_current_limit
/sys/class/power_supply/bms/constant_charge_current_max
/sys/class/power_supply/usb/current_max
/sys/class/power_supply/pc_port/current_max
/sys/class/power_supply/dc/current_max
"

# These take milliamps, not microamps.
KM_CURRENT_NODES_MA="
/sys/class/power_supply/battery/charge_current_max
/sys/devices/platform/charger/charge_current
/sys/module/smb_lib/parameters/fcc_max
"

# Apply a charging current limit, in milliamps.
km_set_charge_current() {
    _ma="$1"
    case "$_ma" in ''|*[!0-9]*) return 1 ;; esac
    _ua=$(( _ma * 1000 ))

    _done=0
    for _p in $KM_CURRENT_NODES_UA; do
        [ -e "$_p" ] || continue
        safe_write "$_p" "$_ua" && _done=$(( _done + 1 ))
    done
    for _p in $KM_CURRENT_NODES_MA; do
        [ -e "$_p" ] || continue
        safe_write "$_p" "$_ma" && _done=$(( _done + 1 ))
    done

    if [ "$_done" -gt 0 ]; then
        log_info "charge current limited to ${_ma}mA ($_done node(s))"
        printf '%s' "$_ma"
        return 0
    fi
    log_unsupported "charge current" "no writable node"
    return 1
}

# Apply a charge ceiling as a percentage (e.g. 80).
# Prints the percentage ACTUALLY applied on stdout.
#
# BUG FIX (v1.8.1): this function clamped its argument internally but the
# CALLERS wrote the raw user value to config. Requesting 1% stored
# CHARGE_LIMIT=1, and km_soft_charge_tick then paused charging at 1% -
# leaving the phone permanently near-empty. The applied value is now
# returned so callers can persist the right number.
km_set_charge_limit() {
    _lim="$1"
    case "$_lim" in ''|*[!0-9]*) return 1 ;; esac

    # 0 is the sanctioned "disable" value and bypasses the floor.
    if [ "$_lim" -eq 0 ]; then
        km_release_charge_hold
        printf '0'
        return 0
    fi

    _lim_req="$_lim"
    [ "$_lim" -lt 50 ] && _lim=50
    [ "$_lim" -gt 100 ] && _lim=100
    if [ "$_lim" != "$_lim_req" ]; then
        log_warn "charge limit ${_lim_req}% clamped to ${_lim}%"
    fi
    _kb=$(km_charge_nodes) || return 1

    _done=0
    for _p in /sys/class/power_supply/battery/charge_control_limit \
              /sys/class/power_supply/battery/battery_charge_control_limit \
              /sys/class/power_supply/bms/charge_control_limit \
              /sys/class/qcom-battery/charge_control_limit ; do
        [ -e "$_p" ] || continue
        safe_write "$_p" "$_lim" && _done=$(( _done + 1 ))
    done

    if [ "$_done" -gt 0 ]; then
        log_info "charge ceiling set to ${_lim}% (native)"
    else
        # Once per boot, not once per profile apply.
        log_unsupported "charge-limit node" "absent; soft limit used instead"
    fi
    printf '%s' "$_lim"
    return 0
}

# Does this kernel offer a NATIVE charge ceiling (as opposed to the soft
# pause fallback)? Used by callers that want to report which is in play.
km_has_native_limit() {
    for _p in /sys/class/power_supply/battery/charge_control_limit \
              /sys/class/power_supply/battery/battery_charge_control_limit \
              /sys/class/power_supply/bms/charge_control_limit \
              /sys/class/qcom-battery/charge_control_limit ; do
        [ -e "$_p" ] && node_writable "$_p" && return 0
    done
    return 1
}

# ----------------------------------------------------------------------
# Diagnostic: find out what THIS kernel actually permits.
# Runs a real write test on every candidate node and reports the reason
# for each failure, distinguishing "missing" from "SELinux" from "EINVAL".
# ----------------------------------------------------------------------
km_probe_charge() {
    printf '\n  Charge control probe\n'
    printf '  ─────────────────────────────────────────\n'

    if _selinux_enforcing; then
        printf '  SELinux      : ENFORCING\n'
    else
        printf '  SELinux      : permissive\n'
    fi
    if command -v magiskpolicy >/dev/null 2>&1; then
        printf '  magiskpolicy : available\n'
    else
        printf '  magiskpolicy : NOT FOUND (cannot grant sysfs access)\n'
    fi
    printf '\n'

    _any=0
    printf '  CURRENT LIMIT NODES\n'
    for _p in $KM_CURRENT_NODES_UA $KM_CURRENT_NODES_MA; do
        _short=$(printf '%s' "$_p" | sed 's#/sys/class/power_supply/##; s#/sys/##')
        if [ ! -e "$_p" ]; then
            continue
        fi
        _cur=$(read_node "$_p" 2>/dev/null)
        if node_writable "$_p"; then
            printf '    [OK]   %-46s = %s\n' "$_short" "${_cur:-?}"
            _any=$(( _any + 1 ))
        else
            if _selinux_enforcing; then
                printf '    [DENY] %-46s (SELinux)\n' "$_short"
            else
                printf '    [DENY] %-46s (read-only)\n' "$_short"
            fi
        fi
    done
    [ "$_any" -eq 0 ] && printf '    none writable\n'

    printf '\n  CHARGE CEILING NODES\n'
    _any2=0
    for _p in /sys/class/power_supply/battery/charge_control_limit \
              /sys/class/power_supply/battery/battery_charge_control_limit \
              /sys/class/power_supply/bms/charge_control_limit ; do
        [ -e "$_p" ] || continue
        _short=$(printf '%s' "$_p" | sed 's#/sys/class/power_supply/##')
        if node_writable "$_p"; then
            printf '    [OK]   %-46s\n' "$_short"
            _any2=$(( _any2 + 1 ))
        else
            printf '    [DENY] %-46s\n' "$_short"
        fi
    done
    [ "$_any2" -eq 0 ] && printf '    none writable\n'

    printf '\n  SOFT LIMIT (charge pause) NODES\n'
    _any3=0
    for _p in /sys/class/power_supply/battery/input_suspend \
              /sys/class/power_supply/battery/battery_charging_enabled \
              /sys/class/power_supply/battery/charging_enabled \
              /sys/class/power_supply/usb/online ; do
        [ -e "$_p" ] || continue
        _short=$(printf '%s' "$_p" | sed 's#/sys/class/power_supply/##')
        if node_writable "$_p"; then
            printf '    [OK]   %-46s = %s\n' "$_short" "$(read_node "$_p")"
            _any3=$(( _any3 + 1 ))
        else
            printf '    [DENY] %-46s\n' "$_short"
        fi
    done
    [ "$_any3" -eq 0 ] && printf '    none writable\n'

    printf '\n  VERDICT\n'
    if [ "$_any" -gt 0 ]; then
        printf '    Charge current CAN be limited on this kernel.\n'
    else
        printf '    Charge current cannot be limited.\n'
    fi
    if [ "$_any2" -gt 0 ]; then
        printf '    Native charge ceiling available.\n'
    elif [ "$_any3" -gt 0 ]; then
        printf '    No native ceiling, but soft limit WILL work.\n'
        printf '    Use:  action.sh limit 80\n'
    else
        printf '    No charge control available on this kernel.\n'
        printf '    Use a lower-wattage charger instead - a 5W brick\n'
        printf '    produces far less heat than an 18W one.\n'
    fi
    printf '\n'
    return 0
}

# Can we do a soft limit at all on this kernel?
km_soft_limit_supported() {
    for _p in /sys/class/power_supply/battery/input_suspend \
              /sys/class/power_supply/battery/battery_charging_enabled \
              /sys/class/power_supply/battery/charging_enabled ; do
        [ -e "$_p" ] && node_writable "$_p" && return 0
    done
    return 1
}

# Soft charge ceiling: suspend charging input above the target percent.
# Used when the kernel has no native charge_control_limit.
# Reversible and checked every service tick.
km_soft_charge_tick() {
    [ "${CHARGE_LIMIT_ENABLED:-0}" = "1" ] || return 0
    _lim="${CHARGE_LIMIT:-80}"
    case "$_lim" in ''|*[!0-9]*) return 0 ;; esac
    # Never act on a limit below the hard floor, whatever config says.
    # This is the last line of defence behind the clamp in the setter.
    if [ "$_lim" -lt 50 ] || [ "$_lim" -gt 100 ]; then
        log_warn "ignoring out-of-range CHARGE_LIMIT=$_lim"
        return 0
    fi

    _kb=$(km_charge_nodes) || return 0
    # Pick whichever pause node this kernel actually permits.
    # Pick a pause node. Preference order matters: input_suspend is the
    # cleanest (1 = stop). The *_charging_enabled nodes are INVERTED
    # (0 = stop), so the polarity is tracked per node rather than
    # assumed - writing the wrong polarity would stop charging forever.
    _sus=""
    _inv=0
    for _c in "$_kb/input_suspend" \
              /sys/class/power_supply/battery/input_suspend ; do
        [ -e "$_c" ] || continue
        node_writable "$_c" || continue
        _sus="$_c"; _inv=0; break
    done
    if [ -z "$_sus" ]; then
        for _c in "$_kb/battery_charging_enabled" \
                  "$_kb/charging_enabled" \
                  /sys/class/power_supply/battery/battery_charging_enabled \
                  /sys/class/power_supply/battery/charging_enabled ; do
            [ -e "$_c" ] || continue
            node_writable "$_c" || continue
            _sus="$_c"; _inv=1; break
        done
    fi
    [ -n "$_sus" ] || return 0

    _cap=$(read_node "$_kb/capacity" 2>/dev/null)
    case "$_cap" in ''|*[!0-9]*) return 0 ;; esac

    _cur=$(read_node "$_sus" 2>/dev/null)

    # Value that means "stop charging" for this node.
    if [ "$_inv" -eq 1 ]; then _stop=0; _go=1; else _stop=1; _go=0; fi

    if [ "$_cap" -ge "$_lim" ]; then
        if [ "$_cur" != "$_stop" ]; then
            safe_write "$_sus" "$_stop"
            log_info "charge paused at ${_cap}% (limit ${_lim}%)"
        fi
    else
        # Resume a few points below so we do not toggle constantly.
        if [ "$_cap" -le $(( _lim - 3 )) ] && [ "$_cur" = "$_stop" ]; then
            safe_write "$_sus" "$_go"
            log_info "charge resumed at ${_cap}%"
        fi
    fi
    return 0
}

# Always release the charge hold when the feature is turned off or the
# module is removed. Leaving input_suspend=1 would stop the phone
# charging at all, which would be a nasty thing to leave behind.
km_release_charge_hold() {
    # Belt and braces: clear every pause node we know about, with the
    # correct polarity for each. Leaving any of these set would stop the
    # phone charging entirely.
    for _p in /sys/class/power_supply/battery/input_suspend \
              /sys/class/power_supply/bms/input_suspend ; do
        [ -e "$_p" ] && safe_write "$_p" 0
    done
    for _p in /sys/class/power_supply/battery/battery_charging_enabled \
              /sys/class/power_supply/battery/charging_enabled \
              /sys/class/power_supply/bms/battery_charging_enabled ; do
        [ -e "$_p" ] && safe_write "$_p" 1
    done
    return 0
}

# ======================================================================
# Wakelocks (inspection only)
# ======================================================================
#
# We report active wakelocks but do NOT block them by default. Blocking
# the wrong wakelock breaks alarms, notifications or the modem. This is
# a diagnostic, not an automatic action.

km_wakelocks() {
    for _w in /sys/power/wake_lock /proc/wakelocks ; do
        if [ -r "$_w" ]; then
            _v=$(read_node "$_w" 2>/dev/null)
            [ -n "$_v" ] && { printf '%s' "$_v"; return 0; }
        fi
    done
    # Fall back to the kernel's own list of active sources.
    if [ -d /sys/kernel/debug/wakeup_sources ]; then
        printf 'see /sys/kernel/debug/wakeup_sources'
        return 0
    fi
    return 1
}

km_block_wakelock() {
    _wl="$1"
    [ -n "$_wl" ] || return 1
    [ -w /sys/power/wake_lock ] || {
        log_unsupported "/sys/power/wake_lock" "not writable"
        return 1
    }
    printf '%s' "$_wl" >/sys/power/wake_lock 2>/dev/null && {
        log_info "wakelock blocked: $_wl"
        return 0
    }
    return 1
}

# ======================================================================
# Apply hook
# ======================================================================

apply_kernel() {
    km_apply_block
    km_apply_tcp

    # Charge current limit is applied whenever configured, because it is
    # the main lever against battery heat.
    # These setters print the value they applied (so the CLI can persist
    # it). apply_kernel runs inside apply_profile, whose stdout the user
    # sees - discard it here or the number leaks into the console.
    [ -n "${CHARGE_CURRENT_MA:-}" ] && km_set_charge_current "$CHARGE_CURRENT_MA" >/dev/null

    if [ "${CHARGE_LIMIT_ENABLED:-0}" = "1" ]; then
        km_set_charge_limit "${CHARGE_LIMIT:-80}" >/dev/null
    else
        km_release_charge_hold
    fi
    return 0
}

# ======================================================================
# Reporting
# ======================================================================

km_report() {
    printf '  I/O sched    : %s\n' "$(km_io_current)"
    _av=$(km_io_available 2>/dev/null)
    [ -n "$_av" ] && printf '                 available: %s\n' "$_av"

    for _kr in $(km_block_devices); do
        _ra=$(read_node "$_kr/queue/read_ahead_kb" 2>/dev/null)
        [ -n "$_ra" ] && { printf '  Read-ahead   : %s KB (%s)\n' "$_ra" "${_kr##*/}"; break; }
    done

    printf '  TCP          : %s\n' "$(km_tcp_current)"
    _zi=$(km_zram_info 2>/dev/null) && printf '  zRAM         : %s\n' "$_zi"

    printf '\n'
    printf '  BATTERY\n'
    _bh=$(km_battery_health 2>/dev/null) && printf '  Condition    : %s\n' "$_bh"
    _rate=$(km_charge_rate_ma 2>/dev/null)
    if [ -n "$_rate" ]; then
        if [ "$_rate" -gt 0 ] 2>/dev/null; then
            printf '  Charge rate  : %s mA (charging)\n' "$_rate"
        else
            printf '  Draw         : %s mA\n' "$_rate"
        fi
    fi
    _kb=$(km_charge_nodes 2>/dev/null)
    if [ -n "$_kb" ] && [ -f "$_kb/constant_charge_current_max" ]; then
        _cl=$(read_node "$_kb/constant_charge_current_max")
        case "$_cl" in
            ''|*[!0-9]*) ;;
            *) printf '  Current cap  : %s mA\n' $(( _cl / 1000 )) ;;
        esac
    fi
    if [ "${CHARGE_LIMIT_ENABLED:-0}" = "1" ]; then
        printf '  Charge limit : %s%% (enabled)\n' "${CHARGE_LIMIT:-80}"
    else
        printf '  Charge limit : off\n'
    fi
    return 0
}
